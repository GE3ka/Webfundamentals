console.log("page loaded...");

let myVideo = document.getElementById("selectedVideo");
function playVideo(){
    myVideo.play();
}

function videoPause() {
    myVideo.pause();
}